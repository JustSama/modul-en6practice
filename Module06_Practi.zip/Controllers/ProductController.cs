using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Module06_Practical_Product_APIKey_JWT.Models;

namespace Module06_Practical_Product_APIKey_JWT.Controllers;

[ApiController]
[Route("api/[controller]")]
public class ProductController : ControllerBase
{
    private readonly IConfiguration _configuration;

    private static readonly List<Product> Products = new()
    {
        new Product { Id = 1, Name = "Laptop", Price = 450000m },
        new Product { Id = 2, Name = "Phone", Price = 320000m },
        new Product { Id = 3, Name = "Headphones", Price = 25000m }
    };

    public ProductController(IConfiguration configuration)
    {
        _configuration = configuration;
    }

    [HttpGet]
    [AllowAnonymous]
    public IActionResult GetProducts([FromHeader(Name = "X-Api-Key")] string? apiKey)
    {
        var expectedKey = _configuration["ApiKey"];
        if (string.IsNullOrWhiteSpace(apiKey) || apiKey != expectedKey)
            return Unauthorized(new { message = "Missing or invalid API key." });

        return Ok(Products);
    }

    [HttpGet("secure")]
    [Authorize]
    public IActionResult GetSecureProducts()
    {
        return Ok(new
        {
            message = "JWT is valid. Access granted.",
            username = User.Identity?.Name,
            products = Products
        });
    }
}
