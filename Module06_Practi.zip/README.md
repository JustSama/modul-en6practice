# Module 06 Practical — Product API Key + JWT

## Requirements
- .NET 8 SDK
- Visual Studio 2022 or .NET CLI

## Run
Open the `.csproj` file in Visual Studio, restore NuGet packages, and run.
Or use:
```bash
dotnet restore
dotnet run
```
Open the Swagger URL shown in the console.

## Task 1–2: API Key
Endpoint: `GET /api/product`
Required header:
`X-Api-Key: SecretKey123`

In Swagger, open the GET endpoint's parameter `apiKey` and enter `SecretKey123`.
- Missing/wrong key: `401 Unauthorized`
- Correct key: `200 OK` with product list

## Task 3–6: JWT
Login:
`POST /api/auth/login`
```json
{
  "username": "student",
  "password": "12345"
}
```
Copy the `token` field. The token includes `Name` and `Role` claims and expires in 2 minutes.

Protected endpoint: `GET /api/product/secure`
- Without token: `401 Unauthorized`
- With valid `Authorization: Bearer <token>`: `200 OK`
- Modified token: `401 Unauthorized`
- Expired token: `401 Unauthorized`

Use Swagger's **Authorize** button and paste the token only.

## Coursework notes
Products are stored in memory and reset when the application restarts. The API key and JWT signing key are demo values for coursework only, not production secrets. For a real application, use secure secret storage and proper user credential storage.
